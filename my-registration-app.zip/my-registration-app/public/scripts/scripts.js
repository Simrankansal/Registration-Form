function validateForm() {
    var name = document.getElementById('name').value;
    var fatherName = document.getElementById('fatherName').value;
    var address = document.getElementById('address').value;
    var pinCode = document.getElementById('pinCode').value;
    var mobileNumber = document.getElementById('mobileNumber').value;
    var email = document.getElementById('email').value;
    var city = document.getElementById('city').value;
    var state = document.getElementById('state').value;
  
  
    if (name === '' || fatherName === '' || address === '' || pinCode === '' || mobileNumber === '' || email === '' || city === '' || state === '') {
      alert('All fields must be filled out');
      return false;
    }
  
    return true;
  }
  